<?php
session_start();
@$_SESSION["resposta10"] = $_REQUEST["resposta10"];
?>
<!DOCTYPE html>
<html lang="PT-BR" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="bootstrap.css">
    <link rel="stylesheet" href="layout.css">
    <script src="jquery-3.4.1.js"></script>
    <script src="validacao.js" charset="utf-8"></script>
    <style>
@import url('https://fonts.googleapis.com/css?family=Quicksand&display=swap');
</style>

<style type="text/css">
*{
  font-family: 'Quicksand', sans-serif;
}
</style>

  </head>
  <body class="fundo">
    <div class="container">

      <div class="row">
        <div class="col-sm">
          <!-- menu -->
          <?php include("menu.php") ?>

        </div>

      </div>
      <div class="row mt-5">
        <div class="col-sm p-5 bg-white">

        <?php
        // Recebe direto do form
        $resp10 = $_REQUEST["resposta10"];
        // Receber respostas da sessão
        $resp9 = $_SESSION["resposta9"];
        $resp8 = $_SESSION["resposta8"];
        $resp7 = $_SESSION["resposta7"];
        $resp6 = $_SESSION["resposta6"];
        $resp5 = $_SESSION["resposta5"];
        $resp4 = $_SESSION["resposta4"];
        $resp3 = $_SESSION["resposta3"];
        $resp2 = $_SESSION["resposta2"];
        $resp1 = $_SESSION["resposta1"];
        //... até 1
        if($resp1 && $resp2 && $resp3 && $resp4 && $resp5 && $resp6 && $resp7 && $resp8 && $resp9 && $resp10 ){



          echo "Sexo: $resp1 <br/>";
          echo "Acordar cedo para você, seria um problema? $resp2 <br/>";
          echo "Você Trabalha e/ou estuda? $resp3 <br/>";
          echo "A ideia de estar no exercito é $resp4 <br/>";
          echo "Você tem responsabilidade com horários e deveres? $resp5 <br/>";
          echo "Você pensa em seguir carreira militar? $resp6 <br/>";
          echo "Arriscar a vida pelo seu país seria um problema? $resp7 <br/>";
          echo "Você gosta de receber ordem/orientações? $resp8 <br/>";
          echo "Você gostaria de servir? $resp9 <br/>";
          echo "Caso seja recutrado para o exército, você ficaria? $resp10 <br/>";
          //Conecta no seu banco de dados
          $con = mysqli_connect("localhost", "root", "", "pergunta");
          // Formata seu comando de inserir com as $resp...
          $insert = "insert into resposta (resp1, resp2, resp3, resp4, resp5, resp6, resp7, resp8, resp9, resp10) values ('$resp1', '$resp2', '$resp3', '$resp4', '$resp5', '$resp6', '$resp7', '$resp8', '$resp9', '$resp10')";

          // Executa o comando
          $resposta = mysqli_query($con, $insert);
          if ($resposta){
            echo "<h3>Respostas salvas com sucesso!</h3>";
            echo "<a href='resposta1.php'>Voltar</a></br>";
            function delete(){

            }
            $select2 = "SELECT id FROM resposta";
            $id = mysqli_insert_id($con);
            $delete = "DELETE FROM resposta WHERE id = '$id'";
            echo "<a href='' onclick='delete''>Excluir Respostas</a></br>";
          } else {
            echo "<h3>Não foi possível salvar suas respostas.</h3>";
            echo "<a href='pergunta1.php'>Voltar<br></a>";
              echo "<a href='perguntar1.php'>Excluir Respostas</a>";

          }
          // fazer a mágica
        } else {
          echo "<h3>Você não respondeu todas as perguntas!</h3>";
          echo "<a href='pergunta1.php'>Voltar<br></a>";
        }
        ?>

      </div>


        </div>
      </div>


    </div>



  </body>
</html>
